<?php
session_start();
require_once 'database_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verkrijg de gegevens van het formulier
    $handle = trim($_POST['handle']);
    $password = $_POST['password'];

    // Validatie van invoer: Handle en wachtwoord mogen niet leeg zijn en de handle moet alfanumeriek zijn.
    if (empty($handle) || empty($password) || !preg_match('/^[a-zA-Z0-9_]+$/', $handle) || strlen($handle) < 3 || strlen($handle) > 20) {
        $_SESSION['errorMessage'] = "Invalid input. Handle must be alphanumeric and between 3 and 20 characters.";
        header("Location: signup.php");
        exit;
    }

    // Wachtwoord hash maken
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        // Controleer of de gebruikersnaam al bestaat
        $stmt = $pdo->prepare("SELECT id FROM users WHERE handle = :handle");
        $stmt->execute(['handle' => $handle]);
        if ($stmt->fetch()) {
            $_SESSION['errorMessage'] = "The username already exists. Please choose another one.";
            header("Location: signup.php");
            exit;
        }

        // Voeg de gebruiker toe aan de database
        $stmt = $pdo->prepare("INSERT INTO users (handle, password) VALUES (:handle, :password)");
        $stmt->execute(['handle' => $handle, 'password' => $hashedPassword]);

        // Zet sessievariabelen voor ingelogde gebruiker
        $_SESSION['userId'] = $pdo->lastInsertId();
        $_SESSION['userHandle'] = $handle;

        // Redirect naar de homepage of een andere pagina na succesvolle registratie
        header("Location: index.php");
        exit;

    } catch (PDOException $e) {
        $_SESSION['errorMessage'] = "Error creating account: " . $e->getMessage();
        header("Location: signup.php");
        exit;
    }
}
?>

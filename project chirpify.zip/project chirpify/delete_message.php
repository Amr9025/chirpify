<?php
session_start();
require_once 'database_connection.php';

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit;
}

// Controleer of het een POST-verzoek is en of een message_id is meegegeven
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['message_id'])) {
    header("Location: index.php?error=" . urlencode("Invalid request."));
    exit;
}

// Valideer CSRF-token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    header("Location: index.php?error=" . urlencode("Invalid CSRF token."));
    exit;
}

$userId = $_SESSION['userId'];
$messageId = $_POST['message_id'];

try {
    $pdo->beginTransaction();

    // Controleer of de gebruiker de eigenaar is van het bericht
    $stmt = $pdo->prepare("SELECT user_id FROM messages WHERE id = :messageId");
    $stmt->execute([':messageId' => $messageId]);
    $message = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$message) {
        header("Location: index.php?error=" . urlencode("Message not found."));
        exit;
    }

    if ($message['user_id'] !== $userId && !isset($_SESSION['is_admin'])) {
        header("Location: index.php?error=" . urlencode("You are not authorized to delete this message."));
        exit;
    }

    // Tel het aantal likes dat wordt verwijderd (voor het aanpassen van de like_count)
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE message_id = :messageId");
    $stmt->execute([':messageId' => $messageId]);
    $likeCount = $stmt->fetchColumn();

    // Verwijder eerst alle retweets (berichten met parent_id gelijk aan messageId)
    $stmt = $pdo->prepare("DELETE FROM messages WHERE parent_id = :messageId");
    $stmt->execute([':messageId' => $messageId]);

    // Verwijder alle likes die verwijzen naar dit bericht
    $stmt = $pdo->prepare("DELETE FROM likes WHERE message_id = :messageId");
    $stmt->execute([':messageId' => $messageId]);

    // Verminder de like_count van de bericht-eigenaar in de users tabel
    if ($likeCount > 0) {
        $stmt = $pdo->prepare("UPDATE users SET like_count = like_count - :likeCount WHERE id = :userId");
        $stmt->execute([
            ':likeCount' => $likeCount,
            ':userId' => $message['user_id']
        ]);
    }

    // Verwijder het bericht zelf
    $stmt = $pdo->prepare("DELETE FROM messages WHERE id = :messageId");
    $stmt->execute([':messageId' => $messageId]);

    $pdo->commit();
    header("Location: index.php?success=" . urlencode("Message deleted successfully."));
    exit;
} catch (PDOException $e) {
    $pdo->rollBack();
    header("Location: index.php?error=" . urlencode("Error deleting message: " . $e->getMessage()));
    exit;
}
?>
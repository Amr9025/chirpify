<?php
// Start de sessie als deze nog niet is gestart
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Stel een standaardtaal in als deze niet is ingesteld of ongeldig is
if (!isset($_SESSION['language']) || !in_array($_SESSION['language'], ['en', 'nl'])) {
    $_SESSION['language'] = 'en';
}

// Debug: Log de waarde van $_SESSION['language']
error_log("header.php: \$_SESSION['language'] = " . ($_SESSION['language'] ?? 'not set'));

// Definieer de $lang array globaal
global $lang;
$language = $_SESSION['language'];
$lang = [
    'en' => [
        'home' => 'Home',
        'profile' => 'Profile',
        'settings' => 'Settings',
        'admin' => 'Admin',
        'logout' => 'Logout',
        'tweet' => 'Tweet',
        'reply' => 'Reply',
        'retweet' => 'Retweet',
        'like' => 'Like',
        'unlike' => 'Unlike',
        'save' => 'Save',
        'whats_chirping' => "What's chirping?"
    ],
    'nl' => [
        'home' => 'Home',
        'profile' => 'Profiel',
        'settings' => 'Instellingen',
        'admin' => 'Admin',
        'logout' => 'Uitloggen',
        'tweet' => 'Chirpen',
        'reply' => 'Antwoorden',
        'retweet' => 'Retweeten',
        'like' => 'Like',
        'unlike' => 'Unlike',
        'save' => 'Opslaan',
        'whats_chirping' => "Wat is er aan het chirpen?"
    ]
];

function renderHeader($activePage) {
    global $lang;
    // Define $theme based on dark_mode session variable
    $theme = isset($_SESSION['dark_mode']) && $_SESSION['dark_mode'] ? 'dark' : '';
    $language = $_SESSION['language'];
    $isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    ?>
    <!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($language); ?>">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Chirpify</title>
        <link rel="stylesheet" href="styles.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    </head>
<body class="<?php echo htmlspecialchars($theme); ?>">
<div class="twitter-container">
    <aside class="sidebar <?php echo htmlspecialchars($theme); ?>">
        <div class="logo">
            <h2>Chirpify</h2>
        </div>
        <nav class="sidebar-nav">
            <a href="index.php" class="nav-item <?php echo $activePage === 'home' ? 'active' : ''; ?> <?php echo htmlspecialchars($theme); ?>">
                <i class="fas fa-home"></i> <?php echo htmlspecialchars($lang[$language]['home']); ?>
            </a>
            <?php if ($isAdmin): ?>
                <a href="admin.php" class="nav-item <?php echo $activePage === 'admin' ? 'active' : ''; ?> <?php echo htmlspecialchars($theme); ?>">
                    <i class="fas fa-user-shield"></i> <?php echo htmlspecialchars($lang[$language]['admin']); ?>
                </a>
            <?php endif; ?>
            <a href="profile.php" class="nav-item <?php echo $activePage === 'profile' ? 'active' : ''; ?> <?php echo htmlspecialchars($theme); ?>">
                <i class="fas fa-user"></i> <?php echo htmlspecialchars($lang[$language]['profile']); ?>
            </a>
            <a href="settings.php" class="nav-item <?php echo $activePage === 'settings' ? 'active' : ''; ?> <?php echo htmlspecialchars($theme); ?>">
                <i class="fas fa-cog"></i> <?php echo htmlspecialchars($lang[$language]['settings']); ?>
            </a>
            <a href="logout.php" class="nav-item <?php echo htmlspecialchars($theme); ?>">
                <i class="fas fa-sign-out-alt"></i> <?php echo htmlspecialchars($lang[$language]['logout']); ?>
            </a>
        </nav>
    </aside>
    <main class="feed">
    <?php
    return $theme; // Return the theme value for use in index.php
}
?>
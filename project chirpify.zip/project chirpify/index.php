<?php
// Start de sessie
session_start();

// Genereer een CSRF-token als deze nog niet bestaat
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Voorkom caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit;
}

// Stel een standaardtaal in als deze niet is ingesteld of ongeldig is
if (!isset($_SESSION['language']) || !in_array($_SESSION['language'], ['en', 'nl'])) {
    $_SESSION['language'] = 'en';
}

require_once 'database_connection.php';
require_once 'header.php';

// Fetch messages from the database
try {
    $stmt = $pdo->prepare("
        SELECT m.id, m.user_id, m.content, m.created_at, m.image, u.handle AS username, u.profile_picture,
               (SELECT COUNT(*) FROM likes WHERE message_id = m.id) AS like_count,
               (SELECT COUNT(*) FROM likes WHERE message_id = m.id AND user_id = :userId) AS user_liked,
               (SELECT COUNT(*) FROM messages WHERE parent_id = m.id) AS retweet_count
        FROM messages m
        JOIN users u ON m.user_id = u.id
        WHERE m.parent_id IS NULL
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([':userId' => $_SESSION['userId']]);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Set a default profile picture if none exists
    foreach ($messages as &$message) {
        $message['profile_picture'] = $message['profile_picture'] ?? 'https://via.placeholder.com/32';
    }
} catch (PDOException $e) {
    $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij ophalen berichten: " . $e->getMessage() : "Error fetching messages: " . $e->getMessage();
    // Display the error for debugging
    echo '<p class="error">' . htmlspecialchars($errorMessage) . '</p>';
}

// Function to calculate time ago
function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;
    if ($diff < 60) return $_SESSION['language'] === 'nl' ? "$diff sec geleden" : "$diff sec ago";
    if ($diff < 3600) return round($diff / 60) . ($_SESSION['language'] === 'nl' ? " min geleden" : " min ago");
    if ($diff < 86400) return round($diff / 3600) . ($_SESSION['language'] === 'nl' ? " uur geleden" : " hours ago");
    return date('d M', strtotime($timestamp));
}

renderHeader('home');
?>

<header class="feed-header">
    <h1><?php echo htmlspecialchars(isset($lang[$_SESSION['language']]['home']) ? $lang[$_SESSION['language']]['home'] : 'Home'); ?></h1>
</header>

<?php if (isset($_GET['error'])): ?>
    <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
<?php endif; ?>
<?php if (isset($_GET['success'])): ?>
    <p class="success"><?php echo htmlspecialchars($_GET['success']); ?></p>
<?php endif; ?>

<div class="post-form">
    <form action="post_message.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
        <textarea name="content" placeholder="<?php echo htmlspecialchars(isset($lang[$_SESSION['language']]['whats_chirping']) ? $lang[$_SESSION['language']]['whats_chirping'] : "What's chirping?"); ?>" required></textarea>
        <div class="form-actions">
            <input type="file" name="image" accept="image/*">
            <button type="submit" class="tweet-btn">
                <i class="fas fa-feather-alt"></i> <?php echo htmlspecialchars($lang[$_SESSION['language']]['tweet']); ?>
            </button>
        </div>
    </form>
</div>

<div class="tweets">
    <?php if (empty($messages)): ?>
        <p><?php echo $_SESSION['language'] === 'nl' ? 'Geen berichten om te tonen.' : 'No messages to display.'; ?></p>
    <?php else: ?>
        <?php foreach ($messages as $message): ?>
            <div class="tweet">
                <div class="tweet-avatar">
                    <img src="<?php echo htmlspecialchars($message['profile_picture']); ?>" alt="User Avatar" style="width: 48px; height: 48px; border-radius: 50%;">
                </div>
                <div class="tweet-content">
                    <div class="tweet-header">
                        <span class="username">@<?php echo htmlspecialchars($message['username']); ?></span>
                        <span class="handle"> · <?php echo htmlspecialchars(timeAgo($message['created_at'])); ?></span>
                    </div>
                    <div class="tweet-body">
                        <p><?php echo htmlspecialchars($message['content']); ?></p>
                        <?php if (!empty($message['image'])): ?>
                            <div class="tweet-image">
                                <img src="<?php echo htmlspecialchars($message['image']); ?>" alt="Tweet Image">
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="message-actions">
                        <a href="reply.php?message_id=<?php echo htmlspecialchars($message['id']); ?>&redirect=index.php" class="action reply">
                            <i class="fas fa-reply"></i> <?php echo htmlspecialchars($lang[$_SESSION['language']]['reply']); ?>
                        </a>
                        <a href="retweet.php?message_id=<?php echo htmlspecialchars($message['id']); ?>&redirect=index.php" class="action retweet">
                            <i class="fas fa-retweet"></i> <?php echo htmlspecialchars($lang[$_SESSION['language']]['retweet']); ?> (<?php echo htmlspecialchars($message['retweet_count']); ?>)
                        </a>
                        <form action="like_message.php" method="POST" style="display: inline;">
                            <input type="hidden" name="messageId" value="<?php echo htmlspecialchars($message['id']); ?>">
                            <button type="submit" class="action like <?php echo $message['user_liked'] ? 'liked' : ''; ?>" style="background: none; border: none; padding: 0; cursor: pointer;">
                                <i class="fas fa-heart"></i> <?php echo htmlspecialchars($message['user_liked'] ? $lang[$_SESSION['language']]['unlike'] : $lang[$_SESSION['language']]['like']); ?> (<?php echo htmlspecialchars($message['like_count']); ?>)
                            </button>
                        </form>
                        <?php if ($message['user_id'] === $_SESSION['userId'] || isset($_SESSION['is_admin'])): ?>
                            <form action="delete_message.php" method="POST" style="display: inline;" onsubmit="return confirm('<?php echo $_SESSION['language'] === 'nl' ? 'Weet je zeker dat je dit bericht wilt verwijderen?' : 'Are you sure you want to delete this message?'; ?>');">
                                <input type="hidden" name="message_id" value="<?php echo htmlspecialchars($message['id']); ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
                                <button type="submit" class="action delete" style="background: none; border: none; padding: 0; cursor: pointer;">
                                    <i class="fas fa-trash"></i> <?php echo htmlspecialchars($lang[$_SESSION['language']]['delete'] ?? 'Delete'); ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</main>
</div>

<script>
document.querySelector('.post-form form').addEventListener('submit', function() {
    // Schakel de submit-knop uit om dubbele submits te voorkomen
    const submitButton = document.querySelector('.tweet-btn');
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-feather-alt"></i> <?php echo htmlspecialchars($lang[$_SESSION['language']]['tweeting'] ?? "Tweeting..."); ?>';
});
</script>

</body>
</html>
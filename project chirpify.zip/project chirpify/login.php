<?php
session_start();
require_once 'database_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $handle = trim($_POST['handle']);
    $password = $_POST['password'];

    if (empty($handle) || empty($password)) {
        $errorMessage = "Handle and password are required.";
        header("Location: login.php?error=" . urlencode($errorMessage));
        exit;
    }

    try {
        $stmt = $pdo->prepare("SELECT id, handle, password, is_admin FROM users WHERE handle = :handle");
        $stmt->execute(['handle' => $handle]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['userId'] = $user['id'];
            $_SESSION['userHandle'] = $user['handle'];
            // Set the role based on is_admin
            $_SESSION['role'] = $user['is_admin'] == 1 ? 'admin' : 'user';
            
            if ($user['is_admin'] == 1) {
                header("Location: admin.php");
            } else {
                header("Location: index.php");
            }
            exit;
        } else {
            $errorMessage = "Invalid handle or password.";
            header("Location: login.php?error=" . urlencode($errorMessage));
            exit;
        }
    } catch (PDOException $e) {
        $errorMessage = "Error logging in: " . $e->getMessage();
        header("Location: login.php?error=" . urlencode($errorMessage));
        exit;
    }
}

// Check for success message from logout
$successMessage = $_SESSION['successMessage'] ?? '';
unset($_SESSION['successMessage']); // Clear the message after displaying
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chirpify - Login</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="signup-container">
        <h2>Login</h2>
        <?php if (isset($_GET['error'])): ?>
            <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
        <?php endif; ?>
        <?php if ($successMessage): ?>
            <p class="success"><?php echo htmlspecialchars($successMessage); ?></p>
        <?php endif; ?>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="handle">Username</label>
                <input type="text" name="handle" id="handle" placeholder="@username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit" class="save-profile-btn"><i class="fas fa-sign-in-alt"></i> Login</button>
        </form>
        <p class="signup-link">Not registered? <a href="signup.php">Sign up here</a></p>
    </div>
</body>
</html>
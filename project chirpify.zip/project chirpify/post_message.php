<?php
session_start();
require_once 'database_connection.php';

// Controleer of de gebruiker is ingelogd en of het een POST-verzoek is
if (!isset($_SESSION['userId']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

// Valideer CSRF-token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $error = $_SESSION['language'] === 'nl' ? "Ongeldige aanvraag." : "Invalid request.";
    header("Location: index.php?error=" . urlencode($error));
    exit;
}

// Genereer een nieuwe CSRF-token voor de volgende form submission
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));

$userId = $_SESSION['userId'];
$content = trim($_POST['content'] ?? '');

// Valideer de lengte van het bericht
if (strlen($content) < 1 || strlen($content) > 1600) {
    $error = $_SESSION['language'] === 'nl' ? "Bericht moet tussen 1 en 1600 tekens lang zijn." : "Message must be between 1 and 1600 characters.";
    header("Location: index.php?error=" . urlencode($error));
    exit;
}

// Controleer of een identieke tweet recentelijk is geplaatst (bijvoorbeeld in de laatste 10 seconden)
try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM messages 
        WHERE user_id = :userId 
        AND content = :content 
        AND created_at >= NOW() - INTERVAL 10 SECOND
    ");
    $stmt->execute([
        ':userId' => $userId,
        ':content' => $content
    ]);
    $recentTweetCount = $stmt->fetchColumn();

    if ($recentTweetCount > 0) {
        // Er is al een identieke tweet geplaatst in de laatste 10 seconden
        $error = $_SESSION['language'] === 'nl' ? "Je hebt dit bericht al recentelijk geplaatst." : "You already posted this message recently.";
        header("Location: index.php?error=" . urlencode($error));
        exit;
    }
} catch (PDOException $e) {
    $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij controle op dubbele berichten: " . $e->getMessage() : "Error checking for duplicate messages: " . $e->getMessage();
    header("Location: index.php?error=" . urlencode($errorMessage));
    exit;
}

$imagePath = null;

// Controleer of een afbeelding is geüpload
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'uploads/';
    // Zorg ervoor dat de uploads-directory bestaat
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    // Genereer een unieke bestandsnaam om conflicten te vermijden
    $fileName = uniqid() . '-' . basename($_FILES['image']['name']);
    $filePath = $uploadDir . $fileName;

    // Verplaats de geüploade afbeelding naar de uploads-directory
    if (move_uploaded_file($_FILES['image']['tmp_name'], $filePath)) {
        $imagePath = $filePath;
    } else {
        $error = $_SESSION['language'] === 'nl' ? "Fout bij het uploaden van de afbeelding." : "Error uploading the image.";
        header("Location: index.php?error=" . urlencode($error));
        exit;
    }
}

// Sla het bericht (en eventueel de afbeelding) op in de database
try {
    $stmt = $pdo->prepare("
        INSERT INTO messages (user_id, content, image, created_at)
        VALUES (:userId, :content, :imagePath, NOW())
    ");
    $stmt->execute([
        ':userId' => $userId,
        ':content' => $content,
        ':imagePath' => $imagePath
    ]);
    header("Location: index.php");
    exit;
} catch (PDOException $e) {
    $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij het plaatsen van het bericht: " . $e->getMessage() : "Error posting message: " . $e->getMessage();
    header("Location: index.php?error=" . urlencode($errorMessage));
    exit;
}
?>
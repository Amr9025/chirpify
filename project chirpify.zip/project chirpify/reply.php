<?php
session_start();

// Voorkom caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit;
}

// Stel een standaardtaal in als deze niet is ingesteld of ongeldig is
if (!isset($_SESSION['language']) || !in_array($_SESSION['language'], ['en', 'nl'])) {
    $_SESSION['language'] = 'en';
}

// Stel een standaardwaarde voor dark_mode in als deze niet is ingesteld
if (!isset($_SESSION['dark_mode'])) {
    $_SESSION['dark_mode'] = false;
}

require_once 'database_connection.php';
require_once 'header.php';

// Debug: Controleer of $lang correct is geladen
if (!isset($lang[$_SESSION['language']])) {
    error_log("reply.php: \$lang[\$_SESSION['language']] is niet ingesteld voor taal: " . $_SESSION['language']);
    $_SESSION['language'] = 'en';
}

$userId = $_SESSION['userId'];
$errorMessage = '';
$successMessage = '';

// Controleer of message_id is opgegeven
if (!isset($_GET['message_id'])) {
    header("Location: index.php?error=" . urlencode("No message specified."));
    exit;
}

$messageId = $_GET['message_id'];

// Haal het originele bericht op
try {
    $stmt = $pdo->prepare("
        SELECT m.id, m.content, m.created_at, m.image, u.handle, u.profile_picture,
               (SELECT COUNT(*) FROM likes WHERE message_id = m.id) AS like_count,
               (SELECT COUNT(*) FROM likes WHERE message_id = m.id AND user_id = :userId) AS user_liked,
               (SELECT COUNT(*) FROM messages WHERE parent_id = m.id) AS retweet_count
        FROM messages m
        JOIN users u ON m.user_id = u.id
        WHERE m.id = :messageId
    ");
    $stmt->execute([':userId' => $userId, ':messageId' => $messageId]);
    $originalMessage = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$originalMessage) {
        header("Location: index.php?error=" . urlencode("Message not found."));
        exit;
    }

    $originalMessage['profile_picture'] = $originalMessage['profile_picture'] ?? 'https://via.placeholder.com/32';
} catch (PDOException $e) {
    $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij ophalen bericht: " . $e->getMessage() : "Error fetching message: " . $e->getMessage();
}

// Haal bestaande replies op
try {
    $stmt = $pdo->prepare("
        SELECT m.id, m.content, m.created_at, m.image, u.handle, u.profile_picture,
               (SELECT COUNT(*) FROM likes WHERE message_id = m.id) AS like_count,
               (SELECT COUNT(*) FROM likes WHERE message_id = m.id AND user_id = :userId) AS user_liked,
               (SELECT COUNT(*) FROM messages WHERE parent_id = m.id) AS retweet_count
        FROM messages m
        JOIN users u ON m.user_id = u.id
        WHERE m.parent_id = :messageId
        ORDER BY m.created_at DESC
    ");
    $stmt->execute([':userId' => $userId, ':messageId' => $messageId]);
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($replies as &$reply) {
        $reply['profile_picture'] = $reply['profile_picture'] ?? 'https://via.placeholder.com/32';
    }
} catch (PDOException $e) {
    $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij ophalen reacties: " . $e->getMessage() : "Error fetching replies: " . $e->getMessage();
    $replies = [];
}

// Verwerk het plaatsen van een reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_reply'])) {
    $content = trim($_POST['content']);
    $uploadDir = 'uploads/';
    $imageFile = '';

    // Zorg ervoor dat de uploadmap bestaat
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (!empty($_FILES['reply_image']['name'])) {
        $imageFile = $uploadDir . basename($_FILES['reply_image']['name']);
        if (!move_uploaded_file($_FILES['reply_image']['tmp_name'], $imageFile)) {
            $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij uploaden afbeelding" : "Error uploading image";
            $imageFile = '';
        }
    }

    if (!$errorMessage && $content) {
        try {
            $stmt = $pdo->prepare("INSERT INTO messages (user_id, content, image, created_at, parent_id) VALUES (:userId, :content, :image, NOW(), :parentId)");
            $stmt->execute([
                ':userId' => $userId,
                ':content' => $content,
                ':image' => $imageFile,
                ':parentId' => $messageId
            ]);
            header("Location: reply.php?message_id=" . $messageId);
            exit;
        } catch (PDOException $e) {
            $errorMessage = $_SESSION['language'] === 'nl' ? "Fout bij plaatsen reactie: " . $e->getMessage() : "Error posting reply: " . $e->getMessage();
        }
    }
}

renderHeader('reply');
?>

<header class="feed-header <?php echo $theme; ?>">
    <h1><?php echo $lang[$_SESSION['language']]['reply']; ?></h1>
</header>

<?php if ($errorMessage): ?>
    <p class="error"><?php echo htmlspecialchars($errorMessage); ?></p>
<?php endif; ?>

<div class="tweet <?php echo $theme; ?>">
    <div class="tweet-avatar">
        <img src="<?php echo htmlspecialchars($originalMessage['profile_picture']); ?>" alt="User Avatar" style="width: 64px; height: 64px; border-radius: 50%;">
    </div>
    <div class="tweet-content">
        <div class="tweet-header">
            <span class="username <?php echo $theme; ?>"><?php echo htmlspecialchars($originalMessage['handle']); ?></span>
            <span class="handle <?php echo $theme; ?>">@<?php echo htmlspecialchars($originalMessage['handle']); ?> · <?php echo timeAgo($originalMessage['created_at']); ?></span>
        </div>
        <p><?php echo htmlspecialchars($originalMessage['content']); ?></p>
        <?php if ($originalMessage['image']): ?>
            <img src="<?php echo htmlspecialchars($originalMessage['image']); ?>" alt="Tweet Image" style="max-width: 100%; border-radius: 8px; margin-top: 10px;">
        <?php endif; ?>
        <div class="tweet-actions">
            <a href="reply.php?message_id=<?php echo $originalMessage['id']; ?>" class="action reply <?php echo $theme; ?>">
                <i class="fas fa-reply"></i> <?php echo $lang[$_SESSION['language']]['reply']; ?>
            </a>
            <a href="retweet.php?message_id=<?php echo $originalMessage['id']; ?>" class="action retweet <?php echo $theme; ?>">
                <i class="fas fa-retweet"></i> <?php echo $lang[$_SESSION['language']]['retweet']; ?> (<?php echo $originalMessage['retweet_count']; ?>)
            </a>
            <form action="like_message.php" method="POST" style="display:inline;">
                <input type="hidden" name="messageId" value="<?php echo $originalMessage['id']; ?>">
                <button type="submit" class="action like <?php echo $theme; ?> <?php echo $originalMessage['user_liked'] ? 'liked' : ''; ?>" style="background: none; border: none; padding: 0; cursor: pointer;">
                    <i class="fas fa-heart"></i> <?php echo $originalMessage['user_liked'] ? $lang[$_SESSION['language']]['unlike'] : $lang[$_SESSION['language']]['like']; ?> (<?php echo $originalMessage['like_count']; ?>)
                </button>
            </form>
        </div>
    </div>
</div>

<div class="tweet-form">
    <form action="reply.php?message_id=<?php echo $messageId; ?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="post_reply" value="1">
        <div class="form-group">
            <textarea name="content" placeholder="<?php echo $_SESSION['language'] === 'nl' ? 'Schrijf een reactie...' : 'Write a reply...'; ?>" required maxlength="1600" class="<?php echo $theme; ?>"></textarea>
        </div>
        <div class="form-group">
            <label for="reply_image"><?php echo $_SESSION['language'] === 'nl' ? 'Afbeelding toevoegen' : 'Add Image'; ?></label>
            <input type="file" name="reply_image" id="reply_image" accept="image/*" class="<?php echo $theme; ?>">
        </div>
        <button type="submit" class="save-profile-btn"><?php echo $lang[$_SESSION['language']]['reply']; ?></button>
    </form>
</div>

<div class="tweets">
    <?php if (empty($replies)): ?>
        <p><?php echo $_SESSION['language'] === 'nl' ? 'Nog geen reacties.' : 'No replies yet.'; ?></p>
    <?php else: ?>
        <?php foreach ($replies as $reply): ?>
            <div class="tweet <?php echo $theme; ?>">
                <div class="tweet-avatar">
                    <img src="<?php echo htmlspecialchars($reply['profile_picture']); ?>" alt="User Avatar" style="width: 64px; height: 64px; border-radius: 50%;">
                </div>
                <div class="tweet-content">
                    <div class="tweet-header">
                        <span class="username <?php echo $theme; ?>"><?php echo htmlspecialchars($reply['handle']); ?></span>
                        <span class="handle <?php echo $theme; ?>">@<?php echo htmlspecialchars($reply['handle']); ?> · <?php echo timeAgo($reply['created_at']); ?></span>
                    </div>
                    <p><?php echo htmlspecialchars($reply['content']); ?></p>
                    <?php if ($reply['image']): ?>
                        <img src="<?php echo htmlspecialchars($reply['image']); ?>" alt="Tweet Image" style="max-width: 100%; border-radius: 8px; margin-top: 10px;">
                    <?php endif; ?>
                    <div class="tweet-actions">
                        <a href="reply.php?message_id=<?php echo $reply['id']; ?>" class="action reply <?php echo $theme; ?>">
                            <i class="fas fa-reply"></i> <?php echo $lang[$_SESSION['language']]['reply']; ?>
                        </a>
                        <a href="retweet.php?message_id=<?php echo $reply['id']; ?>" class="action retweet <?php echo $theme; ?>">
                            <i class="fas fa-retweet"></i> <?php echo $lang[$_SESSION['language']]['retweet']; ?> (<?php echo $reply['retweet_count']; ?>)
                        </a>
                        <form action="like_message.php" method="POST" style="display:inline;">
                            <input type="hidden" name="messageId" value="<?php echo $reply['id']; ?>">
                            <button type="submit" class="action like <?php echo $theme; ?> <?php echo $reply['user_liked'] ? 'liked' : ''; ?>" style="background: none; border: none; padding: 0; cursor: pointer;">
                                <i class="fas fa-heart"></i> <?php echo $reply['user_liked'] ? $lang[$_SESSION['language']]['unlike'] : $lang[$_SESSION['language']]['like']; ?> (<?php echo $reply['like_count']; ?>)
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</main>
</div>
</body>
</html>

<?php
function timeAgo($timestamp) {
    $diff = time() - strtotime($timestamp);
    if ($diff < 60) return $_SESSION['language'] === 'nl' ? "$diff sec geleden" : "$diff sec ago";
    if ($diff < 3600) return round($diff / 60) . ($_SESSION['language'] === 'nl' ? " min geleden" : " min ago");
    if ($diff < 86400) return round($diff / 3600) . ($_SESSION['language'] === 'nl' ? " uur geleden" : " hours ago");
    return date('d M', strtotime($timestamp));
}
?>
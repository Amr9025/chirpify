<?php
session_start();

if (!isset($_SESSION['userId'])) {
    header("Location: login.php");
    exit;
}

require_once 'database_connection.php';

if (isset($_GET['message_id'])) {
    $messageId = $_GET['message_id'];
    $userId = $_SESSION['userId'];

    // Validate the redirect parameter
    $allowedRedirects = ['index.php', 'profile.php', 'reply.php?message_id=' . $messageId];
    $redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';
    
    // Check if the redirect parameter matches an allowed value
    $isValidRedirect = false;
    foreach ($allowedRedirects as $allowed) {
        if ($redirect === $allowed || strpos($redirect, $allowed) === 0) {
            $isValidRedirect = true;
            break;
        }
    }

    if (!$isValidRedirect) {
        $redirect = 'index.php'; // Default to index.php if the redirect is invalid
    }

    try {
        // Fetch the original message
        $stmt = $pdo->prepare("SELECT content, user_id FROM messages WHERE id = :messageId");
        $stmt->execute([':messageId' => $messageId]);
        $originalMessage = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$originalMessage) {
            header("Location: $redirect?error=" . urlencode("Message not found."));
            exit;
        }

        // Insert a new message as a retweet (with parent_id)
        $stmt = $pdo->prepare("INSERT INTO messages (user_id, content, created_at, parent_id) VALUES (:userId, :content, NOW(), :parentId)");
        $stmt->execute([
            ':userId' => $userId,
            ':content' => $originalMessage['content'],
            ':parentId' => $messageId
        ]);

        header("Location: $redirect");
        exit;
    } catch (PDOException $e) {
        header("Location: $redirect?error=" . urlencode("Error retweeting message: " . $e->getMessage()));
        exit;
    }
}

header("Location: index.php");
exit;
?>